"""Run existing repository gates without resetting data or mutating Git releases."""
import hashlib,json,pathlib,subprocess,time,sys
out=pathlib.Path('docs/phase23-evidence');out.mkdir(exist_ok=True)
commands=['build','typecheck','lint','test:unit','test:generator','test:blueprint','test:blueprint-qa','test:solver-v2','test:parametric','test:projects','test:takeoff','test:construction','test:cost','test:workflows','test:interpretation','test:conversations','test:ai-orchestration','test:integration','test:bim','test:supabase','db:test','check']
rows=[]
def manifest():
    files=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z']).decode().split('\0')
    return {f:hashlib.sha256(pathlib.Path(f).read_bytes()).hexdigest() for f in files if f and not f.startswith('docs/') and pathlib.Path(f).is_file()}
initial=manifest()
(out/'tested-source-sha256.json').write_text(json.dumps(initial,indent=2)+'\n')
for script in commands:
    start=time.perf_counter();name=script.replace(':','-');command=['npm','run',script]
    with (out/(name+'.txt')).open('w') as log:
        p=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
    rows.append({'command':' '.join(command),'exitCode':p.returncode,'seconds':round(time.perf_counter()-start,3),'log':str(out/(name+'.txt')),'sourceUnchanged':manifest()==initial})
    (out/'verification.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(rows[-1],flush=True)
    if p.returncode: print('Gate failed; continuing independent gates.',flush=True)
sys.exit(1 if any(r['exitCode'] or not r['sourceUnchanged'] for r in rows) else 0)
