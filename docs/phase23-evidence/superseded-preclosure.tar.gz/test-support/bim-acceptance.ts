import { readBim } from '../apps/api/src/services/bim-service.js';
import { bimRepository } from './bim-repository.js';
import { expect,it } from 'vitest';
import type { ProjectTestContext } from './project-acceptance.js';
import { parametricInput } from './parametric-fixtures.js';
import { BimModelSchema } from '../apps/api/src/bim/contracts.js';
export function bimAcceptance(context:()=>ProjectTestContext) {
  it('Phase 23: owner-only BIM/IFC, bounded pagination, immutable snapshots and revision comparison',async()=>{
    const {app,owner,other}=context();
    const created=await app.inject({method:'POST',url:'/api/projects',headers:owner,payload:{title:'Phase 23 BIM acceptance'}});
    expect(created.statusCode,created.body).toBe(201);const projectId=created.json().id;
    const first=await app.inject({method:'POST',url:`/api/projects/${projectId}/revisions/generate`,headers:owner,payload:{requirements:parametricInput(true)}});
    expect(first.statusCode,first.body).toBe(201);const revision=first.json().revision,base=`/api/projects/${projectId}/revisions/${revision.id}/bim`;
    const read=await app.inject({url:base,headers:owner});expect(read.statusCode,read.body).toBe(200);
    const corrupted = structuredClone(revision); corrupted.identity.modelHash = '0'.repeat(64);
    await expect(readBim(bimRepository(async()=>corrupted),projectId,revision.id)).rejects.toMatchObject({code:'BIM_SOURCE_MISMATCH'});
    const unaccepted = structuredClone(revision); unaccepted.qaRuns[0].status = 'FAIL';
    await expect(readBim(bimRepository(async()=>unaccepted),projectId,revision.id)).rejects.toMatchObject({code:'REVISION_NOT_ACCEPTED'});
    const bim=BimModelSchema.parse(read.json().model);expect(bim.binding.modelHash).toBe(revision.identity.modelHash);
    for (const suffix of ['','/validation','/elements','/relationships','/export.json','/export.ifc',`/elements/${bim.elements[0]!.id}`,`/diff/${revision.id}`]) {
      const unauthorized=await app.inject({url:base+suffix,headers:other});expect(unauthorized.statusCode,unauthorized.body).toBe(404);
      expect((await app.inject({url:base+suffix})).statusCode).toBe(401);
    }
    const ifc=await app.inject({url:base+'/export.ifc',headers:owner});expect(ifc.statusCode,ifc.body.slice(0,300)).toBe(200);expect(ifc.body).toMatch(/^ISO-10303-21;/);expect(ifc.headers['content-type']).toContain('application/x-step');expect(ifc.headers['cache-control']).toBe('no-store');
    expect(ifc.headers['content-disposition']).toContain(revision.id);
    const ids:string[]=[];let after:string|null=null;
    do { const p: Awaited<ReturnType<typeof app.inject>>=await app.inject({url:base+`/elements?limit=7${after?'&after='+after:''}`,headers:owner});expect(p.statusCode,p.body).toBe(200);ids.push(...p.json().items.map((e:{id:string})=>e.id));after=p.json().nextAfter; } while(after);
    expect(ids).toEqual(bim.elements.map(e=>e.id));
    const hosts=await app.inject({url:base+'/relationships?kind=hosts&limit=100',headers:owner});
    expect(hosts.statusCode,hosts.body).toBe(200);
    expect(hosts.json().items).toEqual(bim.relationships.filter(r=>r.kind==='hosts'));
    expect((await app.inject({url:base+'/relationships?kind=wall',headers:owner})).statusCode).toBe(400);
    for(const suffix of ['/elements?limit=101','/elements?after=invalid','/export.ifc?path=../../private','?arbitrary=value']) expect((await app.inject({url:base+suffix,headers:owner})).statusCode).toBe(400);
    const input=parametricInput(true);input.parametricArchitecture.floors[0]!.westWingWidthMm=10000;
    const changed=await app.inject({method:'POST',url:`/api/projects/${projectId}/revisions/generate`,headers:owner,payload:{requirements:input,baseRevisionId:revision.id}});
    expect(changed.statusCode,changed.body).toBe(201);
    const diff=await app.inject({url:base+`/diff/${changed.json().revision.id}`,headers:owner});expect(diff.statusCode,diff.body).toBe(200);expect(diff.json().changes.some((c:{changes:string[]})=>c.changes.includes('MODIFIED_GEOMETRY'))).toBe(true);
    expect((await app.inject({url:base,headers:owner})).body).toBe(read.body);
    const secondProject=await app.inject({method:'POST',url:'/api/projects',headers:owner,payload:{title:'Phase 23 unrelated project'}});
    expect((await app.inject({url:`/api/projects/${secondProject.json().id}/revisions/${revision.id}/bim/export.ifc`,headers:owner})).statusCode).toBe(404);
    expect((await app.inject({method:'POST',url:base,headers:owner,payload:bim})).statusCode).toBe(404);
  });
}
