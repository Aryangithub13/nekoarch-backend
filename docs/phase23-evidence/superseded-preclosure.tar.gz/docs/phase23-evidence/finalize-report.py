"""Finalize evidence after real gates, independent IFC, container and data checks."""
import collections, hashlib, json, pathlib, re, subprocess
out=pathlib.Path('docs/phase23-evidence')
read=lambda name:json.loads((out/name).read_text())
write=lambda name,value:(out/name).write_text(json.dumps(value,indent=2)+'\n')
rows=read('verification.json')
retry=read('supabase-retry.json')
if any(r['exitCode'] for r in rows):
    write('superseded-rest-unavailable/verification.json',rows)
rows=[retry if r['command']=='npm run test:supabase' else r for r in rows]
manifest=read('tested-source-sha256.json')
assert all(hashlib.sha256(pathlib.Path(f).read_bytes()).hexdigest()==h for f,h in manifest.items()),'Source changed after tests'
assert len(rows)==22 and all(r['exitCode']==0 and r['sourceUnchanged'] for r in rows)
write('verification.json',rows)
assert all(r['exitCode']==0 for r in read('supplementary-verification.json'))
assert all(r['unchanged'] for r in read('source-preservation.json').values())
ifc=read('ifc-verification.json')
assert len(ifc['fixtures'])==7 and all(f['schemaDiagnostics']==0 for f in ifc['fixtures'])
assert len(read('ifc-profile-verification.json'))==7
before=read('database-before.json');continued=read('database-continuation-before.json');after=read('database-after.json')
def compare(before,after):
    tables={}
    for key,value in before['tables'].items():
        missing=collections.Counter(value['rowDigests'])-collections.Counter(after['tables'][key]['rowDigests'])
        tables[key]={'beforeCount':value['count'],'afterCount':after['tables'][key]['count'],'missingOriginalRows':sum(missing.values())}
    return {'tables':tables,'migrationHistoryUnchanged':before['migrationHistory']==after['migrationHistory'],'rlsUnchanged':before['rls']==after['rls'],'policiesUnchanged':before['policiesDigest']==after['policiesDigest']}
preservation={'phase23Baseline':compare(before,after),'continuationBaseline':compare(continued,after)}
write('data-preservation.json',preservation)
for result in preservation.values():
    assert all(result[key] for key in ['migrationHistoryUnchanged','rlsUnchanged','policiesUnchanged'])
    assert all(t['missingOriginalRows']==0 for t in result['tables'].values())
report=pathlib.Path('docs/phase23-report.md');text=report.read_text()
gate=['| Command | Exit | Passed tests | Seconds | Evidence |','|---|---:|---:|---:|---|']
for r in rows:
    log=pathlib.Path(r['log']).read_text()
    counts=re.findall(r'\bTests\s+(\d+) passed',log) or re.findall(r'Tests=(\d+)',log)
    gate.append(f"| `{r['command']}` | {r['exitCode']} | {' / '.join(counts) or '—'} | {r['seconds']:.3f} | [log](phase23-evidence/{pathlib.Path(r['log']).name}) |")
text=text.replace('<!-- GATE_TABLE -->','\n'.join(gate))
bench=read('benchmark.json')['measurements']
perf=['| Fixture | Elements | Projection | Edge construction | Validation | IFC + validation | Self-diff | Export bytes |','|---|---:|---:|---:|---:|---:|---:|---:|']
for b in bench:
    perf.append(f"| {b['name']} | {b['elements']} | {b['projectionAndRelationshipsMs']:.2f} | {b['relationshipEdgeConstructionMs']:.2f} | {b['validationMs']:.2f} | {b['ifcSerializationAndValidationMs']:.2f} | {b['diffMs']:.2f} | {b['exportBytes']} |")
text=text.replace('<!-- BENCHMARK_TABLE -->','\n'.join(perf))
peak=max(b['processPeakRssBytes'] for b in bench);parser=max(f['parserPeakRssBytes'] for f in ifc['fixtures'])
text=text.replace('<!-- MEMORY_SUMMARY -->',f"Highest sampled Node process peak RSS was {peak} bytes ({peak/1048576:.1f} MiB); independent parser process peak RSS was {parser} bytes ({parser/1048576:.1f} MiB). These are process observations, not per-request allocation. Full measurements: [benchmark.json](phase23-evidence/benchmark.json) and [IFC verification](phase23-evidence/ifc-verification.json).")
text=text.replace('<!-- DATA_SUMMARY -->',f"Every original public-table row digest was preserved against both the initial Phase 23 baseline and this continuation baseline. Initial Phase 23 counts were **{before['tables']['projects']['count']} projects and {before['tables']['project_revisions']['count']} revisions**; continuation started with {continued['tables']['projects']['count']} projects and {continued['tables']['project_revisions']['count']} revisions. Final counts are **{after['tables']['projects']['count']} projects and {after['tables']['project_revisions']['count']} revisions**. Migration history, RLS flags and policy digests are unchanged. [Data preservation](phase23-evidence/data-preservation.json) records all table comparisons.")
text=text.replace('<!-- FINAL_CLASSIFICATION -->','**FULLY IMPLEMENTED AND VERIFIED**')
text=text.replace('<!-- RELEASE_READINESS -->','All required gates for the documented bounded Phase 23 profile passed. Recommend `backend-v1-phase23-complete` after user review and release approval. Changes remain unstaged and uncommitted on `main`; the release tag has not been created.')
assert '<!--' not in text
report.write_text(text)
subprocess.run(['git','diff','--check'],stdout=(out/'diff-check.txt').open('w'),stderr=subprocess.STDOUT,check=True)
write('git-final.json',{'branch':subprocess.check_output(['git','branch','--show-current']).decode().strip(),'head':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'phase22Tag':subprocess.check_output(['git','rev-parse','backend-v1-phase22-complete']).decode().strip(),'phase23Tags':subprocess.check_output(['git','tag','--list','backend-v1-phase23-complete']).decode().splitlines(),'stagedFiles':subprocess.check_output(['git','diff','--cached','--name-only']).decode().splitlines()})
write('changed-files.json',[])
changed=set(subprocess.check_output(['git','diff','--name-only','HEAD','-z']).decode().split('\0'))|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z']).decode().split('\0'))
write('changed-files.json',sorted(f for f in changed if f))
write('evidence-sha256.json',{str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(out.rglob('*')) if f.is_file() and f.name!='evidence-sha256.json'})
# Include the newly written evidence manifest in the complete path inventory.
paths=read('changed-files.json');paths.append(str(out/'evidence-sha256.json'));write('changed-files.json',sorted(set(paths)))
write('evidence-sha256.json',{str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(out.rglob('*')) if f.is_file() and f.name!='evidence-sha256.json'})
print(json.dumps({'classification':'FULLY IMPLEMENTED AND VERIFIED','gates':len(rows),'independentIfcFixtures':len(ifc['fixtures']),'protectedFiles':len(read('source-preservation.json')),'changedFiles':len(read('changed-files.json'))}))
